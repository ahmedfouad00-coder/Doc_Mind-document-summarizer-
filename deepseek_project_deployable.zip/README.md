
# deepseek - converted project (auto-generated)

This project was auto-generated from `deepseek.ipynb` and contains:

- `scripts/notebook_code.py` - a concatenation of all code cells from the notebook (fallback).
- `app/` - FastAPI skeleton and inference wrapper that tries to call functions from `notebook_code.py`.
- `scripts/train.py` - training stub that will call `train()` or similar if available.
- `scripts/data_prep.py` - data preparation stub.
- `requirements.txt` - guessed requirements based on imports found in the notebook.
- `Dockerfile`, `run.sh`

## How to use

1. Inspect `scripts/notebook_code.py` and refactor: move relevant functions into `app/services/` as needed.
2. Adapt `app/services/inference.py` to call your project's real inference function.
3. Install dependencies: `pip install -r requirements.txt`
4. Run locally: `./run.sh`  then open `http://127.0.0.1:8000/docs`
5. To package: `docker build -t deepseek .` and run the container.

## Notes
- This is an automatic conversion. It's a **starting point** — some manual refactoring is required.
- Open `scripts/notebook_code.py`, find the function that does inference/prediction and wire it into `app/services/inference.py`




---
## Automatic CI / Deployment (push to GitHub -> build image)

This repository includes GitHub Actions workflows that **build a Docker image** and **publish it to GitHub Container Registry (GHCR)** automatically on every push to `main` or `master`.

- `.github/workflows/publish.yml` — builds and pushes `ghcr.io/<your-username>/deepseek:latest`. **No extra secrets required** (uses `GITHUB_TOKEN` and repository permissions). After a push, check the Actions tab and the Packages (GHCR) to find the image.

### Optional: Fully automatic deploy to Google Cloud Run (one secret)

If you want the repository to **deploy automatically** to Google Cloud Run after each push, set these repository secrets in GitHub (Settings → Secrets → Actions):

- `GCP_SA_KEY` — the JSON service account key (as plain JSON) with permissions to deploy to Cloud Run and push to GCR.
- `GCP_PROJECT_ID` — your GCP project id.
- `GCP_REGION` — e.g. `us-central1`.

Once those secrets are added, the `deploy-gcp-run.yml` workflow will run on push and deploy the Docker image to Cloud Run.

### Alternative: One-click deploy to Render / Railway

If you prefer not to add any secrets, use a hosting provider that supports **connect-to-GitHub** (Render, Railway, Fly.io). Steps (minimal):

1. Sign up on Render (or Railway).
2. Create a new service and connect your GitHub repo (no code changes required).
3. The provider will build the Dockerfile and deploy automatically on push.

---
